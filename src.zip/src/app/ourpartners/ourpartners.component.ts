import { Component } from '@angular/core';

@Component({
  selector: 'app-ourpartners',
  templateUrl: './ourpartners.component.html',
  styleUrls: ['./ourpartners.component.css']
})
export class OurpartnersComponent {

}
